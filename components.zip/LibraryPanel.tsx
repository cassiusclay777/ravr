import { useCallback } from 'react';
import { useAudioEngine } from '@/hooks/useAudioEngine';
import { usePlayer } from '@/state/playerStore';
import { useLibrary } from '@/hooks/useLibrary';

// Simple SVG Icons to avoid external dependencies
const PlayIcon = ({ className }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
  </svg>
);

const PauseIcon = ({ className }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 9v6m4-6v6m7-3a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

const PlusIcon = ({ className }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
  </svg>
);

const XMarkIcon = ({ className }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
  </svg>
);

const MusicalNoteIcon = ({ className }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3" />
  </svg>
);

const ListBulletIcon = ({ className }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16m-7 6h7" />
  </svg>
);

interface LibraryPanelProps {
  readonly open: boolean;
  readonly onClose: () => void;
}

export function LibraryPanel({ open, onClose }: LibraryPanelProps) {
  const { tracks, addFolder } = useLibrary();
  const { load, play, pause, isPlaying } = useAudioEngine();
  const { current, setCurrent } = usePlayer();

  const handleTrackClick = useCallback((track: any) => {
    if (current?.id === track.id && isPlaying) {
      pause();
    } else {
      setCurrent(track);
      load(track.url);
      play();
    }
  }, [current, isPlaying, load, pause, play, setCurrent]);

  const handleAddFolder = useCallback(() => {
    addFolder();
  }, [addFolder]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-40">
      <button
        className="w-full text-left p-2 hover:bg-white/10 rounded flex items-center gap-2 focus:outline-none focus:ring-2 focus:ring-cyan-400"
        onClick={handleAddFolder}
        onKeyDown={(e) => e.key === 'Enter' && handleAddFolder()}
      >
        <PlusIcon className="w-4 h-4" />
        <span>Add Folder</span>
      </button>
      <aside className="fixed inset-y-0 left-0 w-[360px] bg-ravr-panel/95 backdrop-blur-lg border-r border-white/10 z-50 flex flex-col">
        <div className="p-4 border-b border-white/10">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-white/90 font-semibold text-lg">Library</h2>
            <button 
              onClick={onClose} 
              className="p-1 rounded-full hover:bg-white/10 text-white/70 hover:text-white transition-colors"
              aria-label="Close library"
            >
              <XMarkIcon className="w-5 h-5" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-4 pt-2">
            <div>
              <div className="text-xs text-white/60 mb-2 px-1">
                {tracks.length} {tracks.length === 1 ? 'track' : 'tracks'}
              </div>
              <div className="space-y-1">
                {tracks.map((track) => {
                  const isCurrent = current?.id === track.id;
                  return (
                    <button
                      key={track.id}
                      className={`group flex items-center gap-3 rounded-lg p-2 text-sm transition-colors ${
                        isCurrent ? 'bg-white/10' : 'hover:bg-white/5'
                      }`}
                      onClick={() => handleTrackClick(track)}
                      onKeyDown={(e) => e.key === 'Enter' && handleTrackClick(track)}
                      title={`${isCurrent && isPlaying ? 'Pause' : 'Play'} ${track.name}`}
                    >
                      <button
                        className={`p-1.5 rounded-full flex-shrink-0 ${
                          isCurrent && isPlaying 
                            ? 'text-white bg-rose-600 hover:bg-rose-500' 
                            : 'text-white/70 hover:text-white hover:bg-white/10'
                        } transition-colors`}
                        aria-label={isCurrent && isPlaying ? 'Pause track' : 'Play track'}
                        title={isCurrent && isPlaying ? 'Pause track' : 'Play track'}
                      >
                        {isCurrent && isPlaying ? (
                          <PauseIcon className="w-4 h-4" />
                        ) : (
                          <PlayIcon className="w-4 h-4" />
                        )}
                      </button>
                      <div 
                        className="flex-1 min-w-0 truncate cursor-default"
                      >
                        <div className={`truncate ${isCurrent ? 'text-white' : 'text-white/90'}`}>
                          {track.name}
                        </div>
                        <div className="text-xs text-white/50 truncate">
                          {track.url.replace(/^.*[\\/]/, '')}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </aside>
    </div>
  );
}
