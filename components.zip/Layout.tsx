import React from "react";
import { clsx } from "clsx";
import { Link, useLocation } from "react-router-dom";
import AudioControls from "./AudioControls";

export function Layout({ children }: { readonly children: React.ReactNode }) {
  const location = useLocation();
  
  const isActive = (path: string) => {
    if (path === "/" && location.pathname === "/") return true;
    if (path !== "/" && location.pathname.startsWith(path)) return true;
    return false;
  };

  return (
    <div className="min-h-dvh bg-ravr-gradient text-white">
      <header className="sticky top-0 z-20 backdrop-blur-xl bg-black/30 border-b border-white/10 shadow-neon animate-glow-pulse">
        <div className="mx-auto max-w-6xl px-4 py-3 flex items-center justify-between">
          <h1 className="text-xl font-semibold tracking-wide neon-text">
            <span className="text-ravr-accent">RAVR</span> Player
          </h1>
          <nav className="flex gap-4 text-sm opacity-90">
            <Link 
              to="/" 
              className={`hover:text-ravr-accent transition ${isActive("/") ? "text-ravr-accent font-medium" : ""}`}
            >
              Player
            </Link>
            <Link 
              to="/dsp" 
              className={`hover:text-ravr-accent transition ${isActive("/dsp") ? "text-ravr-accent font-medium" : ""}`}
            >
              DSP
            </Link>
            <Link 
              to="/settings" 
              className={`hover:text-ravr-accent transition ${isActive("/settings") ? "text-ravr-accent font-medium" : ""}`}
            >
              Settings
            </Link>
          </nav>
        </div>
      </header>

      {/* 🎵 ALWAYS-PRESENT AUDIO PLAYER - Srdce RAVRu! */}
      <div className="sticky top-16 z-10 mx-auto max-w-6xl px-4 py-4">
        <AudioControls />
      </div>

      <main className={clsx("mx-auto max-w-6xl px-4 py-8 space-y-8")}> 
        <div className="rounded-2xl bg-white/5 backdrop-blur-xl shadow-neon p-6 animate-fade"> 
          {children}
        </div>
      </main>
      <footer className="mt-12 py-6 text-center text-xs text-white/50">
        RAVR · industrial techno engine
      </footer>
    </div>
  );
}