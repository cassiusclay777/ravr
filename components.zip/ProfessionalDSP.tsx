import React, { useState } from 'react';
import { BsSliders } from 'react-icons/bs';
import { HiSparkles } from 'react-icons/hi';
import { FiZap, FiActivity, FiTarget } from 'react-icons/fi';
import Slider from 'rc-slider';

interface DSPEffect {
  id: string;
  name: string;
  enabled: boolean;
  params: Record<string, number>;
  icon: React.ReactNode;
  color: string;
}

interface EffectParametersProps {
  effect: DSPEffect;
  onParamUpdate: (effectId: string, param: string, value: number) => void;
  getParameterUnit: (param: string) => string;
  getParameterRange: (param: string) => { min: number; max: number; step: number };
  getSliderTrackColor: (color: string) => string;
  formatParameterValue: (value: number) => string | number;
}

const EffectParameters: React.FC<EffectParametersProps> = ({
  effect,
  onParamUpdate,
  getParameterUnit,
  getParameterRange,
  getSliderTrackColor,
  formatParameterValue
}) => {
  return (
    <div className="space-y-4">
      {Object.entries(effect.params).map(([param, value]) => {
        const range = getParameterRange(param);
        const unit = getParameterUnit(param);
        const trackColor = getSliderTrackColor(effect.color);
        
        return (
          <div key={param} className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-white/70 capitalize">{param}</span>
              <span className="text-white/90 font-mono">
                {formatParameterValue(value)}{unit}
              </span>
            </div>
            <Slider
              min={range.min}
              max={range.max}
              step={range.step}
              value={value}
              onChange={(newValue) => onParamUpdate(effect.id, param, Array.isArray(newValue) ? newValue[0] : newValue)}
              disabled={!effect.enabled}
              styles={{
                track: { 
                  height: 4,
                  backgroundColor: effect.enabled ? `rgb(${trackColor})` : '#6b7280',
                  borderRadius: 2
                },
                handle: {
                  borderColor: effect.enabled ? `rgb(${trackColor})` : '#6b7280',
                  backgroundColor: '#ffffff',
                  opacity: effect.enabled ? 1 : 0.5,
                  height: 16,
                  width: 16,
                  marginTop: -6,
                },
                rail: { 
                  backgroundColor: 'rgba(255,255,255,0.08)', 
                  height: 4,
                  borderRadius: 2
                },
              }}
            />
          </div>
        );
      })}
    </div>
  );
};

export const ProfessionalDSP: React.FC = () => {
  const [effects, setEffects] = useState<DSPEffect[]>([
    {
      id: 'reverb',
      name: 'Hall Reverb',
      enabled: false,
      params: { roomSize: 0.5, decay: 0.3, wet: 0.2 },
      icon: <FiActivity />,
      color: 'cyan'
    },
    {
      id: 'delay',
      name: 'Stereo Delay',
      enabled: false,
      params: { time: 250, feedback: 0.3, wet: 0.15 },
      icon: <FiActivity />,
      color: 'blue'
    },
    {
      id: 'exciter',
      name: 'Harmonic Exciter',
      enabled: false,
      params: { drive: 0.4, harmonics: 0.3, output: 0.8 },
      icon: <FiZap />,
      color: 'purple'
    },
    {
      id: 'enhancer',
      name: 'Bass Enhancer',
      enabled: true,
      params: { frequency: 80, boost: 3, q: 0.7 },
      icon: <FiTarget />,
      color: 'green'
    }
  ]);

  const toggleEffect = (id: string) => {
    setEffects(prev => prev.map(effect => 
      effect.id === id ? { ...effect, enabled: !effect.enabled } : effect
    ));
  };

  const updateParam = (effectId: string, param: string, value: number) => {
    setEffects(prev => prev.map(effect => 
      effect.id === effectId 
        ? { ...effect, params: { ...effect.params, [param]: value } }
        : effect
    ));
  };

  const getColorClasses = (color: string, enabled: boolean) => {
    const disabledClass = 'from-gray-500/10 to-gray-600/5 border-gray-500/20 text-gray-400';
    
    if (!enabled) return disabledClass;
    
    const enabledColorMap = {
      cyan: 'from-cyan-500/20 to-cyan-600/10 border-cyan-500/30 text-cyan-400',
      blue: 'from-blue-500/20 to-blue-600/10 border-blue-500/30 text-blue-400',
      purple: 'from-purple-500/20 to-purple-600/10 border-purple-500/30 text-purple-400',
      green: 'from-green-500/20 to-green-600/10 border-green-500/30 text-green-400',
    };
    
    return enabledColorMap[color as keyof typeof enabledColorMap] || enabledColorMap.cyan;
  };

  const getParameterUnit = (param: string) => {
    if (param === 'time') return 'ms';
    if (param.includes('frequency')) return 'Hz';
    return '';
  };

  const getParameterRange = (param: string) => {
    if (param === 'time') return { min: 50, max: 1000, step: 10 };
    if (param === 'frequency') return { min: 20, max: 200, step: 5 };
    return { min: 0, max: 1, step: 0.01 };
  };

  const getSliderTrackColor = (color: string) => {
    const colorMap = {
      cyan: '34 197 94',
      blue: '59 130 246', 
      purple: '147 51 234',
      green: '34 197 94'
    };
    return colorMap[color as keyof typeof colorMap] || colorMap.cyan;
  };

  const formatParameterValue = (value: number) => {
    return typeof value === 'number' && value < 1 ? value.toFixed(2) : value;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3 mb-6">
        <BsSliders className="text-cyan-400 text-xl" />
        <h2 className="text-2xl font-bold text-white/90">Professional DSP Suite</h2>
        <HiSparkles className="text-yellow-400 text-lg" />
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {effects.map((effect) => (
          <div
            key={effect.id}
            className={`rounded-2xl bg-gradient-to-br border backdrop-blur-sm p-6 transition-all duration-300 ${getColorClasses(effect.color, effect.enabled)}`}
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-lg bg-black/20 ${effect.enabled ? 'text-current' : 'text-gray-400'}`}>
                  {effect.icon}
                </div>
                <div>
                  <h3 className="font-semibold text-white/90">{effect.name}</h3>
                  <p className="text-xs text-white/50">
                    {effect.enabled ? 'Active' : 'Bypassed'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => toggleEffect(effect.id)}
                className={`w-12 h-6 rounded-full transition-all duration-300 relative ${
                  effect.enabled 
                    ? `bg-${effect.color}-500` 
                    : 'bg-gray-600'
                }`}
              >
                <div
                  className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow-lg transition-transform duration-300 ${
                    effect.enabled ? 'translate-x-6' : 'translate-x-0.5'
                  }`}
                />
              </button>
            </div>

            <EffectParameters 
              effect={effect}
              onParamUpdate={updateParam}
              getParameterUnit={getParameterUnit}
              getParameterRange={getParameterRange}
              getSliderTrackColor={getSliderTrackColor}
              formatParameterValue={formatParameterValue}
            />
          </div>
        ))}
      </div>
    </div>
  );
};
