import React, { useEffect, useState } from 'react';
import { FiPlay, FiPause, FiZap, FiHeart } from 'react-icons/fi';
import { HiSparkles } from 'react-icons/hi';

export const WelcomeAudioDemo: React.FC = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [isLoaded, setIsLoaded] = useState(false);

  // Simulace audio pro demo účely
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isPlaying) {
      interval = setInterval(() => {
        setCurrentTime(prev => prev + 0.1);
      }, 100);
    }
    return () => clearInterval(interval);
  }, [isPlaying]);

  const togglePlay = () => {
    setIsPlaying(!isPlaying);
    if (!isLoaded) {
      setIsLoaded(true);
      // Simulate loading a beautiful track
      setTimeout(() => {
        console.log('🎵 RAVR: Loaded beautiful ambient track');
      }, 500);
    }
  };

  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  return (
    <div className="glass-card rounded-[2rem] p-8 space-y-6 relative overflow-hidden">
      {/* Animated Background Effects */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute -top-8 -left-8 w-32 h-32 bg-gradient-to-r from-cyan-400/20 to-blue-500/20 rounded-full blur-[40px] animate-pulse"></div>
        <div className="absolute -bottom-8 -right-8 w-40 h-40 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-full blur-[50px] animate-bounce"></div>
      </div>

      {/* Header */}
      <div className="relative z-10 text-center">
        <div className="flex items-center justify-center gap-3 mb-4">
          <div className="w-12 h-12 bg-gradient-to-br from-cyan-500 to-purple-600 rounded-xl shadow-lg flex items-center justify-center">
            <FiHeart className="text-white text-xl" />
          </div>
          <div>
            <h3 className="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-purple-600 bg-clip-text text-transparent">
              Hudba je láska
            </h3>
            <p className="text-white/60 text-sm">Zkus si náš zážitek</p>
          </div>
          <HiSparkles className="text-yellow-400 text-xl animate-spin" />
        </div>
      </div>

      {/* Demo Track Info */}
      <div className="relative z-10 text-center space-y-2">
        <h4 className="text-lg font-semibold text-white/90">
          {isLoaded ? "✨ Něco krásného" : "🎵 Kousek hudby"}
        </h4>
        <p className="text-white/60 text-sm">
          {isLoaded ? "Ambient · Enhanced" : "Stlač play a poslouchej"}
        </p>
      </div>

      {/* Playback Controls */}
      <div className="relative z-10 flex items-center justify-center gap-6">
        <button
          onClick={togglePlay}
          className="group relative w-16 h-16 bg-gradient-to-br from-cyan-500 via-blue-500 to-purple-600 hover:from-cyan-400 hover:via-blue-400 hover:to-purple-500 rounded-full shadow-lg hover:shadow-cyan-500/25 transition-all duration-300 transform hover:scale-110 active:scale-95"
        >
          <div className="absolute inset-0 rounded-full bg-gradient-to-br from-white/20 to-transparent opacity-50"></div>
          {isPlaying ? (
            <FiPause className="relative z-10 text-white text-2xl mx-auto" />
          ) : (
            <FiPlay className="relative z-10 text-white text-2xl mx-auto ml-1" />
          )}
          
          {/* Pulsing ring when playing */}
          {isPlaying && (
            <div className="absolute inset-0 rounded-full border-2 border-cyan-400/50 animate-ping"></div>
          )}
        </button>

        {/* Time Display */}
        <div className="text-center">
          <div className="text-white/90 font-mono text-lg">
            {formatTime(currentTime)}
          </div>
          <div className="text-white/50 text-xs">
            {isPlaying ? "Playing" : "Ready"}
          </div>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="relative z-10 space-y-2">
        <div className="w-full h-2 bg-white/10 rounded-full overflow-hidden">
          <div 
            className="h-full bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600 rounded-full transition-all duration-100"
            style={{ width: isPlaying ? `${Math.min((currentTime % 30) / 30 * 100, 100)}%` : '0%' }}
          ></div>
        </div>
        <div className="flex justify-between text-xs text-white/50">
          <span>0:00</span>
          <span>Demo Track</span>
          <span>0:30</span>
        </div>
      </div>

      {/* Subtle Features Highlight */}
      <div className="relative z-10 grid grid-cols-3 gap-4 text-center opacity-60">
        <div className="space-y-2">
          <FiZap className="mx-auto text-cyan-400 text-lg" />
          <p className="text-xs text-white/50">Enhanced</p>
        </div>
        <div className="space-y-2">
          <FiHeart className="mx-auto text-pink-400 text-lg" />
          <p className="text-xs text-white/50">With Love</p>
        </div>
        <div className="space-y-2">
          <HiSparkles className="mx-auto text-yellow-400 text-lg" />
          <p className="text-xs text-white/50">Beautiful</p>
        </div>
      </div>

      {/* Call to Action */}
      {isPlaying && (
        <div className="relative z-10 text-center animate-fade-in">
          <p className="text-white/70 text-sm">
            🎧 Cítíš ten rozdíl? 
          </p>
          <p className="text-cyan-400 text-xs mt-2">
            Zkus nahraj svoji hudbu do playeru ⬆️
          </p>
        </div>
      )}
    </div>
  );
};
