import * as React from 'react';
import { useState, useEffect, useRef } from 'react';
import AIMastering, { Genre } from '../ai/AIMastering';

const GENRES = [
  'pop',
  'rock',
  'classical',
  'jazz',
  'electronic',
  'hiphop',
  'metal'
] as const;

function AIMasteringPanel() {
  const [isProcessing, setIsProcessing] = useState(false);
  const [intensity, setIntensity] = useState(70);
  const [selectedGenre, setSelectedGenre] = useState<Genre>('pop');
  const [status, setStatus] = useState('Ready');
  
  const masteringEngine = useRef<AIMastering | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const sourceNodeRef = useRef<AudioBufferSourceNode | null>(null);

  // Initialize mastering engine on mount
  useEffect(() => {
    masteringEngine.current = new AIMastering();
    masteringEngine.current.initialize(selectedGenre)
      .then(() => setStatus('Ready'))
      .catch(console.error);

    return () => {
      if (masteringEngine.current) {
        masteringEngine.current.dispose();
      }
    };
  }, []);

  const handleGenreChange = async (genre: Genre) => {
    if (masteringEngine.current) {
      setStatus('Loading model...');
      try {
        await masteringEngine.current.changeGenre(genre);
        setSelectedGenre(genre);
        setStatus('Ready');
      } catch (error) {
        console.error('Failed to change genre:', error);
        setStatus('Error changing genre');
      }
    }
  };

  const handleIntensityChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newIntensity = parseInt(e.target.value) / 100;
    setIntensity(parseInt(e.target.value));
    if (masteringEngine.current) {
      masteringEngine.current.setIntensity(newIntensity);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !masteringEngine.current) return;

    setIsProcessing(true);
    setStatus('Processing...');

    try {
      // Read file as ArrayBuffer
      const arrayBuffer = await file.arrayBuffer();
      
      // Create AudioContext if it doesn't exist
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      const audioContext = audioContextRef.current;
      
      // Decode audio data
      const audioBuffer = await audioContext.decodeAudioData(arrayBuffer);
      
      // Process with AI Mastering
      const processedBuffer = await masteringEngine.current.process(audioBuffer);
      
      // Create a new source node for playback
      if (sourceNodeRef.current) {
        sourceNodeRef.current.stop();
      }
      
      const source = audioContext.createBufferSource();
      source.buffer = processedBuffer;
      source.connect(audioContext.destination);
      source.start();
      sourceNodeRef.current = source;
      
      setStatus('Playing processed audio');
    } catch (error) {
      console.error('Error processing audio:', error);
      setStatus('Error processing audio');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="ai-mastering-panel p-6 bg-gray-800 rounded-lg shadow-lg text-white">
      <h2 className="text-2xl font-bold mb-4">AI Mastering</h2>
      
      <div className="mb-6">
        <fieldset className="border border-gray-600 rounded p-4">
          <legend className="text-sm font-medium px-2">Genre</legend>
          <div className="flex flex-wrap gap-2">
            {GENRES.map((genre) => (
              <label
                key={genre}
                className={`px-3 py-1 rounded-full text-sm font-medium transition-colors cursor-pointer ${
                  selectedGenre === genre
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                }`}
              >
                <input
                  type="radio"
                  name="genre-selector"
                  checked={selectedGenre === genre}
                  onChange={() => handleGenreChange(genre)}
                  className="sr-only"
                  disabled={isProcessing}
                />
                {genre.charAt(0).toUpperCase() + genre.slice(1)}
              </label>
            ))}
          </div>
        </fieldset>
      </div>
      
      <div className="mb-6">
        <label htmlFor="intensity-slider" className="block text-sm font-medium mb-2">
          Intensity: {intensity}%
        </label>
        <input
          id="intensity-slider"
          type="range"
          min="0"
          max="100"
          value={intensity}
          onChange={handleIntensityChange}
          className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
          disabled={isProcessing}
          aria-valuemin={0}
          aria-valuemax={100}
          aria-valuenow={intensity}
        />
      </div>
      
      <div className="mb-4">
        <label htmlFor="audio-file" className="block text-sm font-medium mb-2">Upload Audio</label>
        <input
          id="audio-file"
          type="file"
          accept=".mp3,.wav,.flac,.aac,.ogg"
          onChange={handleFileUpload}
          disabled={isProcessing}
          className="block w-full text-sm text-gray-400
            file:mr-4 file:py-2 file:px-4
            file:rounded-md file:border-0
            file:text-sm file:font-semibold
            file:bg-blue-500 file:text-white
            hover:file:bg-blue-600
            disabled:opacity-50 disabled:cursor-not-allowed"
        />
      </div>
      
      <output className="block mt-4 p-3 bg-gray-700 rounded text-sm" aria-live="polite">
        <span className="font-medium">Status:</span> {status}
      </output>
    </div>
  );
};

export default AIMasteringPanel;
