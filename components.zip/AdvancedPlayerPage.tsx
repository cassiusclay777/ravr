import Background from "@/components/Background";
import { Layout } from "@/components/Layout";
import { useRef, useEffect, useState } from 'react';
import { useAudioStore, Track } from '../store/audioStore';
import AudioPreview from './AudioPreview/AudioPreview';

export default function AdvancedPlayerPage() {
  const { 
    isPlaying, 
    setIsPlaying, 
    currentTime, 
    setCurrentTime,
    duration, 
    setDuration, 
    volume, 
    setVolume,
    currentTrack,
    setCurrentTrack
  } = useAudioStore();
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Initialize audio element
  useEffect(() => {
    let audioElement = document.getElementById('ravr-audio') as HTMLAudioElement;
    if (!audioElement) {
      audioElement = document.createElement('audio');
      audioElement.id = 'ravr-audio';
      audioElement.className = 'hidden';
      document.body.appendChild(audioElement);
    }
    audioRef.current = audioElement;

    // Set up event listeners
    const handleTimeUpdate = () => setCurrentTime(audioElement.currentTime);
    const handleLoadedMetadata = () => setDuration(audioElement.duration);
    const handlePlay = () => setIsPlaying(true);
    const handlePause = () => setIsPlaying(false);
    const handleEnded = () => setIsPlaying(false);

    audioElement.addEventListener('timeupdate', handleTimeUpdate);
    audioElement.addEventListener('loadedmetadata', handleLoadedMetadata);
    audioElement.addEventListener('play', handlePlay);
    audioElement.addEventListener('pause', handlePause);
    audioElement.addEventListener('ended', handleEnded);

    return () => {
      audioElement.removeEventListener('timeupdate', handleTimeUpdate);
      audioElement.removeEventListener('loadedmetadata', handleLoadedMetadata);
      audioElement.removeEventListener('play', handlePlay);
      audioElement.removeEventListener('pause', handlePause);
      audioElement.removeEventListener('ended', handleEnded);
    };
  }, [setCurrentTime, setDuration, setIsPlaying]);

  // Update audio volume when store changes
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume;
    }
  }, [volume]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && file.type.startsWith('audio/') && audioRef.current) {
      console.log('Loading audio file:', file.name);
      
      const url = URL.createObjectURL(file);
      audioRef.current.src = url;
      
      const track: Track = {
        id: Date.now().toString(),
        name: file.name,
        artist: 'Unknown Artist',
        album: 'Unknown Album',
        duration: 0,
        url: url
      };
      
      setCurrentTrack(track);
    }
  };

  const togglePlayPause = async () => {
    if (!audioRef.current) return;
    
    try {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        await audioRef.current.play();
      }
    } catch (error) {
      console.error('Playback error:', error);
    }
  };

  const handleSeek = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!audioRef.current || duration === 0) return;
    
    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const seekTime = (clickX / rect.width) * duration;
    
    audioRef.current.currentTime = Math.max(0, Math.min(seekTime, duration));
  };

  return (
    <>
      <Background />
      <Layout>
        <h1 className="text-2xl font-semibold text-cyan-300 mb-4">RAVR Advanced</h1>

        {/* Professional File Drop Zone */}
        <div className="mb-8 rounded-3xl border-2 border-dashed border-cyan-400/30 bg-gradient-to-br from-black/40 via-gray-900/30 to-purple-900/20 p-8 shadow-2xl backdrop-blur-2xl hover:border-cyan-400/50 transition-all duration-300 group">
          <div className="text-center relative">
            <div className="mb-4">
              <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-cyan-400 to-purple-600 rounded-full shadow-lg group-hover:scale-110 transition-transform duration-300">
                <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                </svg>
              </div>
            </div>
            <h3 className="text-xl font-bold text-white/90 mb-2">Drop Your Audio Files Here</h3>
            <p className="text-white/60 mb-4">Supports MP3, FLAC, WAV, M4A, OGG and more</p>
            <button 
              className="px-8 py-3 bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 text-white font-semibold rounded-full shadow-lg hover:shadow-cyan-500/25 transition-all duration-300 transform hover:scale-105"
              onClick={() => fileInputRef.current?.click()}
            >
              Choose Files
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept="audio/*,video/*"
              onChange={handleFileUpload}
              className="hidden"
              multiple
            />
          </div>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <Card title="Player Controls">
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <button 
                  onClick={togglePlayPause}
                  className="px-4 py-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-white transition-colors flex items-center gap-2"
                >
                  {isPlaying ? '⏸️' : '▶️'} {isPlaying ? 'Pause' : 'Play'}
                </button>
                <button className="px-3 py-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-white transition-colors">
                  ⏹️
                </button>
                <button className="px-3 py-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-white transition-colors">
                  ⏮️
                </button>
                <button className="px-3 py-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-white transition-colors">
                  ⏭️
                </button>
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-xs text-white/60">
                  <span>{formatTime(currentTime)}</span>
                  <div 
                    className="h-2 flex-1 rounded bg-white/10 cursor-pointer"
                    onClick={handleSeek}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' || e.key === ' ') {
                        handleSeek(e as any);
                      }
                    }}
                    role="slider"
                    tabIndex={0}
                    aria-valuemin={0}
                    aria-valuemax={duration}
                    aria-valuenow={currentTime}
                    aria-label="Seek position"
                  >
                    <div 
                      className="h-2 rounded bg-cyan-400 transition-all" 
                      style={{ width: `${duration > 0 ? (currentTime / duration) * 100 : 0}%` }}
                    />
                  </div>
                  <span>{formatTime(duration)}</span>
                </div>
                
                <div className="flex items-center gap-2">
                  <span className="text-xs text-white/60">🔊</span>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.01"
                    value={volume}
                    onChange={(e) => setVolume(parseFloat(e.target.value))}
                    className="flex-1 h-2 bg-white/10 rounded-lg appearance-none slider"
                  />
                  <span className="text-xs text-white/60 w-8">{Math.round(volume * 100)}%</span>
                </div>
              </div>
            </div>
            <p className="mt-2 text-xs text-white/60">192k / {formatTime(duration)}</p>
          </Card>

          <Card title="AI Suggestions">
            <p className="text-white/60">Load audio file for AI analysis</p>
          </Card>
        </div>

        <Card className="mt-6" title="3D Spectrum Analyzer">
          <div className="h-72 rounded-xl bg-black/70 ring-1 ring-white/5" />
        </Card>

        <div className="grid gap-6 md:grid-cols-3 mt-6">
          <Card title="Stem Separation">
            {["Off", "Karaoke", "Drums", "Bass", "Instruments"].map((t,i)=>(
              <button key={t} className={`w-full text-left px-3 py-2 rounded-lg mb-2 ${i===0?'bg-purple-600 text-white':'bg-slate-700/70 text-white/80 hover:bg-slate-600/70'}`}>{t}</button>
            ))}
          </Card>

          <Card title="Spatial Audio">
            <label className="inline-flex items-center gap-2">
              <input type="checkbox" className="size-4 accent-cyan-500" />
              <span className="text-white/80">Enable 3D Audio</span>
            </label>
          </Card>

          <Card title="Track Info">
            <p className="text-white/60">No track identified</p>
          </Card>
        </div>
      </Layout>
    </>
  );
}

function Card({
  title, children, className=""
}: {title:string; children:React.ReactNode; className?:string}) {
  return (
    <section className={`rounded-2xl border border-white/10 bg-ravr-panel/70 p-6 shadow-xl backdrop-blur ${className}`}>
      <h2 className="mb-4 text-lg font-semibold text-white/90">{title}</h2>
      {children}
    </section>
  );
}
